<?php
// Conexión a MySQL
$conn = new mysqli("localhost", "root", "", "recomendaciones_db");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>