<?php
include("conexion.php");

$sql = "SELECT * FROM lugares ORDER BY fecha_creacion DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<h3>" . $row['nombre_lugar'] . "</h3>";
        echo "<img src='" . $row['imagen_url'] . "' alt='Imagen del lugar' style='width:300px; border-radius:10px;'><br>";
        echo "<p>" . $row['recomendacion'] . "</p>";
        echo "<small>Registrado el: " . $row['fecha_creacion'] . "</small>";
        echo "<hr>";
    }
} else {
    echo "No hay recomendaciones aún.";
}
?>
