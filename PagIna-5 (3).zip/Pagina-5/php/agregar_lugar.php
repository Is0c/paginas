<?php
include("conexion.php");

$nombre = $_POST['nombre_lugar'];
$imagen = $_POST['imagen_url'];
$reco   = $_POST['recomendacion'];

$sql = "INSERT INTO lugares (nombre_lugar, imagen_url, recomendacion) 
        VALUES ('$nombre', '$imagen', '$reco')";

if ($conn->query($sql) === TRUE) {
    echo "Lugar guardado correctamente";
} else {
    echo "Error: No se pudo guardar";
}
?>
