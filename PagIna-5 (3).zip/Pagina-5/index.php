<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recomendacion-lugares</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Pagina Web de recomendaciones</h1>
        <div class="links">
            <a href="#inicio">inicio</a>
            <a href="#Contactos">Contactos</a>
            <a href="./form.html">Registrar_lugar</a>
        </div>
    </header>

    <h1>Bienvenido a la Pagina Web de Recomendaciones</h1>
    <h2>¡Descubre en la ciudad de mar del plata con nosotros y deja que cada viaje sea una obra maestra!</h2>

    <br>

    <h2>Recomendaciones de lugares</h2>

    <br>

    <!-- Aquí se mostrarán las recomendaciones -->
    <?php include("php/obtener_lugar.php"); ?>
</body>
</html>