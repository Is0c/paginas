-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-11-2025 a las 15:27:38
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `recomendaciones_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugares`
--

CREATE TABLE `lugares` (
  `id` int(11) NOT NULL,
  `nombre_lugar` varchar(255) NOT NULL,
  `imagen_url` varchar(500) DEFAULT NULL,
  `recomendacion` text NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `lugares`
--

INSERT INTO `lugares` (`id`, `nombre_lugar`, `imagen_url`, `recomendacion`, `fecha_creacion`) VALUES
(1, 'Centro Comercial y Cultural Aldrey', 'https://hotelselent.com.ar/wp-content/uploads/2017/09/Paseo-Aldrey-1-800x500.gif', 'Ubicado en la antigua Terminal de Ómnibus, es el punto de encuentro social ideal. Este centro comercial tiene tiendas de moda, tecnología, una gran sala de cines y un food court con muchas opciones de comida rápida y variada. Es el lugar perfecto para pasar un rato, hacer compras, almorzar o ir al cine.', '2025-11-28 13:07:39'),
(2, 'Playa Grande (Zona de Paradores y Surf)', 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/16/df/e8/12/playa-grande.jpg?w=1200&h=-1&s=1', 'Si buscan ambiente playero y social, esta es la mejor zona. Playa Grande es conocida por ser el centro del surf en Mar del Plata. En sus paradores encontrarán música, canchas deportivas, y un ambiente más juvenil y trendy que otras playas. Es ideal para tomar sol, ver surfistas, o simplemente pasar el rato con amigos en la arena.', '2025-11-28 14:11:11');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `lugares`
--
ALTER TABLE `lugares`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `lugares`
--
ALTER TABLE `lugares`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
